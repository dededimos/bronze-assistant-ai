# Bronze Assistant AI

This is a basic AI assistant configurator using React + ShadCN UI.
